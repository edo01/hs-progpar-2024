/*!
 * \file
 * \brief Visualization module.
 */

#pragma once

#include "motion/visu/visu_struct.h"
#include "motion/visu/visu_io.h"
